# LÖVE Hello World - Web Export

- Run `run_server.bat` 
- Open a browser to http://localhost:8000

## Controls
- Press ESC to quit
- Use the "Go Fullscreen" button for fullscreen mode 